package dao;

import java.util.List;

import model.Customer;

public interface CustomerDAO {
	
	void save(Customer custoemer);
	Customer get(int id);
	List<Customer> getAll();
	void update(Customer customer);
	void delete(int id);
	
	

}
