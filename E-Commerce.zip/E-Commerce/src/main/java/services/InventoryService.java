package services;

import model.Item;
import model.Order;

public interface InventoryService {
	
	
void orderItemFromVendor(Item item);






}
