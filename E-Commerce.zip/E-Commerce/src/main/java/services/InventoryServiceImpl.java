package services;

import model.Item;
import model.Order;

public class InventoryServiceImpl implements InventoryService{

	@Override
	public void orderItemFromVendor(Item item) {
		// TODO Auto-generated method stub
		
	}

}
